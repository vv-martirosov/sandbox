/* =====================================================================
   AI UCP Control Panel — App shell & UI behaviours
   ===================================================================== */
(function () {
  'use strict';

  /* ---------- Navigation model ---------- */
  const NAV = [
    { title: 'Обзор', items: [
      { key: 'index',        label: 'Дашборд',          icon: 'layout-dashboard', href: 'index.html' },
      { key: 'sessions',     label: 'Активные сессии',  icon: 'activity',         href: 'sessions.html', badge: '7' },
      { key: 'reports',      label: 'Отчёты · Value',   icon: 'bar-chart-3',      href: 'reports.html' },
    ]},
    { title: 'Агенты и сценарии', items: [
      { key: 'agents-list',   label: 'Агенты',           icon: 'bot',              href: 'agents-list.html' },
      { key: 'scenarios-list',label: 'Сценарии',         icon: 'workflow',         href: 'scenarios-list.html' },
      { key: 'research-list', label: 'Исследования',     icon: 'radar',            href: 'research-list.html', badge: 'β' },
    ]},
    { title: 'База знаний', items: [
      { key: 'skills-library', label: 'Навыки',          icon: 'sparkles',        href: 'skills-library.html' },
      { key: 'integrations',   label: 'Интеграции',      icon: 'plug',            href: 'integrations.html' },
      { key: 'knowledge-bases',label: 'RAG · Справочники',icon: 'library',        href: 'knowledge-bases.html' },
      { key: 'wiki',           label: 'Wiki',            icon: 'book-open-text',  href: 'wiki.html' },
      { key: 'widget-registry',label: 'Реестр виджетов', icon: 'layout-grid',     href: 'widget-registry.html' },
      { key: 'widget-screen-preview', label: 'Конструктор экрана', icon: 'smartphone', href: 'widget-screen-preview.html' },
      { key: 'env-variables',  label: 'Переменные',      icon: 'key-round',       href: 'env-variables.html' },
    ]},
    { title: 'Интерфейсы', items: [
      { key: 'domains',        label: 'Домены',           icon: 'globe',           href: 'domains.html' },
      { key: 'surfaces',       label: 'Поверхности',      icon: 'layout-template', href: 'surfaces.html' },
      { key: 'landings',       label: 'Лендинги',         icon: 'panels-top-left', href: 'landings.html' },
      { key: 'servers',        label: 'Сервера',          icon: 'server',          href: 'servers.html' },
    ]},
    { title: 'Наблюдаемость', items: [
      { key: 'observability', label: 'Обзор',            icon: 'gauge',           href: 'observability.html' },
      { key: 'logs',          label: 'Логи',             icon: 'scroll-text',     href: 'logs.html' },
      { key: 'traces',        label: 'Трассировка',      icon: 'git-branch',      href: 'traces.html' },
      { key: 'metrics',       label: 'Метрики',          icon: 'line-chart',      href: 'metrics.html' },
    ]},
    { title: 'Администрирование', items: [
      { key: 'users',        label: 'Пользователи',      icon: 'users',           href: 'users.html' },
      { key: 'organization', label: 'Организация',       icon: 'building-2',      href: 'organization.html' },
      { key: 'general-settings', label: 'Настройки',     icon: 'settings',        href: 'general-settings.html' },
      { key: 'ui-kit',       label: 'UI Kit',            icon: 'component',       href: 'ui-kit.html' },
    ]},
  ];

  const NOTIFS = [
    { ic:'check-circle', cl:'ok',   t:'Сценарий «Онбординг клиента» завершён', s:'12 шагов · 4.2 c · 2 мин назад' },
    { ic:'alert-triangle', cl:'warn', t:'Агент «Скоринг» — рост latency p95', s:'до 3.1 c · 9 мин назад' },
    { ic:'x-circle', cl:'err', t:'Ошибка вызова инструмента «CRM API»', s:'timeout · 14 мин назад' },
    { ic:'user-plus', cl:'info', t:'Новый пользователь: А. Петров', s:'роль: Оператор · 40 мин назад' },
  ];

  /* ---------- Shell rendering ---------- */
  function buildSidebar(active) {
    const groups = NAV.map(g => `
      <div class="sb-group">
        <div class="sb-group-t">${g.title}</div>
        ${g.items.map(it => `
          <a class="sb-link ${it.key === active ? 'active' : ''}" href="${it.href}">
            <i data-lucide="${it.icon}" class="i"></i>
            <span class="sb-txt">${it.label}</span>
            ${it.badge ? `<span class="sb-badge">${it.badge}</span>` : ''}
          </a>`).join('')}
      </div>`).join('');

    return `
      <aside class="sidebar">
        <div class="sb-brand">
          <div class="sb-logo"><i data-lucide="hexagon" class="i-lg"></i></div>
          <div class="sb-txt"><b>AI UCP</b><small>Control Panel</small></div>
        </div>
        <nav class="sb-nav">${groups}</nav>
        <div class="sb-foot">
          <div class="sb-user" data-menu="userMenu">
            <div class="avatar sm">МВ<span class="avatar-status on"></span></div>
            <div class="sb-txt"><b>Марти В.</b><span>Product Owner</span></div>
            <i data-lucide="chevrons-up-down" class="i-sm sb-txt" style="margin-left:auto;color:#7fb894"></i>
          </div>
        </div>
      </aside>`;
  }

  function buildTopbar() {
    return `
      <header class="topbar">
        <div class="tb-toggle mobile" data-nav-toggle><i data-lucide="menu" class="i"></i></div>
        <div class="tb-toggle desktop" data-collapse><i data-lucide="panel-left-close" class="i"></i></div>
        <div class="tb-search">
          <i data-lucide="search" class="i"></i>
          <input type="text" placeholder="Поиск агентов, сценариев, логов…" id="globalSearch">
          <kbd>/</kbd>
        </div>
        <div class="tb-actions">
          <div class="tb-btn tooltip" data-tip="Создать" data-menu="createMenu"><i data-lucide="plus" class="i"></i></div>
          <div class="tb-btn tooltip" data-tip="Помощь"><i data-lucide="life-buoy" class="i"></i></div>
          <div class="tb-btn" data-menu="notifMenu"><i data-lucide="bell" class="i"></i><span class="ping"></span></div>
          <div class="tb-divider"></div>
          <div class="tb-btn" data-menu="userMenu2"><div class="avatar sm">МВ</div></div>
        </div>
      </header>`;
  }

  /* ---------- Menus (popovers) ---------- */
  const MENUS = {
    createMenu: `
      <div class="menu-label">Создать</div>
      <a class="menu-item" href="agent-create.html"><i data-lucide="bot"></i>Нового агента</a>
      <a class="menu-item" href="scenario-create.html"><i data-lucide="workflow"></i>Сценарий</a>
      <a class="menu-item" href="skill-wizard.html"><i data-lucide="sparkles"></i>Навык / интеграцию</a>
      <a class="menu-item" href="wiki-create.html"><i data-lucide="book-open-text"></i>Запись в Wiki</a>`,
    notifMenu: `
      <div class="menu-label" style="display:flex;justify-content:space-between;align-items:center">Уведомления
        <span class="badge badge-danger" style="height:18px">4 новых</span></div>
      ${NOTIFS.map(n => `<div class="menu-item" style="align-items:flex-start;gap:11px;padding:10px">
        <div class="toast-ic ${n.cl}" style="width:30px;height:30px"><i data-lucide="${n.ic}" class="i-sm"></i></div>
        <div style="min-width:0"><div style="font-weight:600;font-size:13px;white-space:normal">${n.t}</div>
        <div class="muted t-xs" style="margin-top:2px">${n.s}</div></div></div>`).join('')}
      <div class="menu-sep"></div>
      <a class="menu-item" href="notifications.html" style="justify-content:center;color:var(--brand-700);font-weight:600">Показать все</a>`,
    userMenu: `
      <div class="menu-item" style="pointer-events:none"><div class="avatar sm">МВ</div>
        <div><b style="font-size:13px">Марти Вартанов</b><div class="muted t-xs">martirosov@sber.ru</div></div></div>
      <div class="menu-sep"></div>
      <a class="menu-item" href="users.html"><i data-lucide="user"></i>Мой профиль</a>
      <a class="menu-item" href="organization.html"><i data-lucide="building-2"></i>Организация</a>
      <a class="menu-item" href="general-settings.html"><i data-lucide="settings"></i>Настройки</a>
      <div class="menu-sep"></div>
      <a class="menu-item danger" href="auth.html"><i data-lucide="log-out"></i>Выйти</a>`,
    srvMenu: `
      <div class="menu-item" data-toast="info|Метрики|Открываю графики сервера"><i data-lucide="line-chart"></i>Метрики</div>
      <a class="menu-item" href="logs.html"><i data-lucide="scroll-text"></i>Логи</a>
      <div class="menu-item" data-toast="info|Перезапуск|Сервер перезапускается…"><i data-lucide="power"></i>Перезапустить</div>
      <div class="menu-item" data-toast="warn|Обслуживание|Режим обслуживания включён"><i data-lucide="wrench"></i>Режим обслуживания</div>
      <div class="menu-sep"></div>
      <div class="menu-item danger" data-toast="warn|Снят|Сервер снят с мониторинга"><i data-lucide="trash-2"></i>Снять с мониторинга</div>`,
    domMenu: `
      <div class="menu-item" data-toast="info|DNS|Запущена проверка DNS"><i data-lucide="refresh-cw"></i>Проверить DNS</div>
      <div class="menu-item" data-toast="ok|SSL|Сертификат перевыпущен"><i data-lucide="shield-check"></i>Перевыпустить SSL</div>
      <a class="menu-item" href="surfaces.html"><i data-lucide="layout-template"></i>Привязать поверхность</a>
      <div class="menu-sep"></div>
      <div class="menu-item danger" data-toast="warn|Удалено|Домен откреплён"><i data-lucide="trash-2"></i>Удалить</div>`,
    scnMenu: `
      <a class="menu-item" href="scenarios.html"><i data-lucide="pencil"></i>Открыть в конструкторе</a>
      <div class="menu-item" data-toast="info|Запуск|Сценарий поставлен в очередь"><i data-lucide="play"></i>Запустить</div>
      <a class="menu-item" href="reports.html"><i data-lucide="bar-chart-3"></i>Value-отчёт</a>
      <div class="menu-item" data-toast="ok|Скопировано|Создан дубликат сценария"><i data-lucide="copy"></i>Дублировать</div>
      <div class="menu-sep"></div>
      <div class="menu-item danger" data-toast="warn|Пауза|Сценарий приостановлен"><i data-lucide="pause"></i>Поставить на паузу</div>`,
    rowMenu: `
      <a class="menu-item" href="user-card.html"><i data-lucide="eye"></i>Открыть карточку</a>
      <a class="menu-item" href="user-card.html"><i data-lucide="pencil"></i>Редактировать</a>
      <div class="menu-item" data-toast="info|Сброс|Ссылка на сброс пароля отправлена"><i data-lucide="key-round"></i>Сбросить пароль</div>
      <div class="menu-sep"></div>
      <div class="menu-item danger" data-toast="warn|Доступ|Пользователь заблокирован"><i data-lucide="ban"></i>Заблокировать</div>`,
  };
  MENUS.userMenu2 = MENUS.userMenu;

  /* ---------- Popover controller ---------- */
  let openPop = null;
  function closePop() { if (openPop) { openPop.remove(); openPop = null; } }
  function openMenu(anchor, key) {
    closePop();
    const m = document.createElement('div');
    m.className = 'menu';
    m.innerHTML = MENUS[key] || '';
    document.body.appendChild(m);
    const r = anchor.getBoundingClientRect();
    let left = r.left, top = r.bottom + 6;
    if (key === 'userMenu') { top = r.top - m.offsetHeight - 6; }
    if (key === 'notifMenu') { m.style.width = '340px'; }
    if (left + m.offsetWidth > innerWidth - 12) left = innerWidth - m.offsetWidth - 12;
    if (top + m.offsetHeight > innerHeight - 12) top = r.top - m.offsetHeight - 6;
    m.style.left = Math.max(12, left) + 'px';
    m.style.top = Math.max(12, top) + 'px';
    openPop = m;
    if (window.lucide) lucide.createIcons();
  }

  /* ---------- Toasts ---------- */
  const ICONS = { ok:'check-circle', err:'x-circle', warn:'alert-triangle', info:'info' };
  const TITLES = { ok:'Готово', err:'Ошибка', warn:'Внимание', info:'Информация' };
  function toast(type, title, msg) {
    let wrap = document.querySelector('.toast-wrap');
    if (!wrap) { wrap = document.createElement('div'); wrap.className = 'toast-wrap'; document.body.appendChild(wrap); }
    const el = document.createElement('div');
    el.className = 'toast';
    el.innerHTML = `<div class="toast-ic ${type}"><i data-lucide="${ICONS[type]}" class="i-sm"></i></div>
      <div style="min-width:0"><b>${title || TITLES[type]}</b><p>${msg || ''}</p></div>
      <div class="tx"><i data-lucide="x" class="i-sm"></i></div><div class="bar"></div>`;
    wrap.appendChild(el);
    if (window.lucide) lucide.createIcons();
    const kill = () => { el.classList.add('out'); setTimeout(() => el.remove(), 220); };
    el.querySelector('.tx').onclick = kill;
    setTimeout(kill, 4000);
  }
  window.toast = toast;

  /* ---------- Modal ---------- */
  function openModal(html, opts) {
    opts = opts || {};
    const ov = document.createElement('div');
    ov.className = 'overlay';
    ov.innerHTML = `<div class="modal ${opts.lg ? 'lg' : ''}">${html}</div>`;
    document.body.appendChild(ov);
    if (window.lucide) lucide.createIcons();
    const close = () => ov.remove();
    ov.addEventListener('click', e => { if (e.target === ov) close(); });
    ov.querySelectorAll('[data-close]').forEach(b => b.onclick = close);
    return { el: ov, close };
  }
  window.openModal = openModal;

  function modalFromTemplate(id) {
    const tpl = document.getElementById(id);
    if (!tpl) return;
    return openModal(tpl.innerHTML, { lg: tpl.dataset.lg === '1' });
  }

  /* ---------- Lightbox ---------- */
  function lightbox(src) {
    const lb = document.createElement('div');
    lb.className = 'lightbox';
    lb.innerHTML = `<div class="lb-close"><i data-lucide="x" class="i-lg"></i></div><img src="${src}" alt="">`;
    document.body.appendChild(lb);
    if (window.lucide) lucide.createIcons();
    lb.addEventListener('click', () => lb.remove());
  }

  /* ---------- Tabs (in-page) ---------- */
  function initTabs(root) {
    (root || document).querySelectorAll('[data-tabs]').forEach(group => {
      group.querySelectorAll('[data-tab]').forEach(btn => {
        btn.addEventListener('click', e => {
          e.preventDefault();
          const id = btn.dataset.tab;
          group.querySelectorAll('[data-tab]').forEach(b => b.classList.toggle('active', b === btn));
          document.querySelectorAll('[data-panel]').forEach(p => {
            if (p.dataset.panel === id) p.classList.remove('hide');
            else if (group.contains(document.querySelector(`[data-tab="${p.dataset.panel}"]`))) p.classList.add('hide');
          });
        });
      });
    });
  }

  /* ---------- Mount ---------- */
  function mount() {
    const app = document.querySelector('.app[data-page]');
    if (!app) { afterMount(); return; }
    const active = app.dataset.page;
    app.insertAdjacentHTML('afterbegin', buildSidebar(active));
    const main = app.querySelector('.main');
    if (main) main.insertAdjacentHTML('afterbegin', buildTopbar());
    app.insertAdjacentHTML('beforeend', '<div class="backdrop" data-nav-toggle></div>');
    afterMount();
  }

  function afterMount() {
    if (window.lucide) lucide.createIcons();
    initTabs();

    document.addEventListener('click', e => {
      // menus
      const trg = e.target.closest('[data-menu]');
      if (trg) { e.stopPropagation();
        const key = trg.dataset.menu;
        if (openPop && openPop._key === key) { closePop(); return; }
        openMenu(trg, key); if (openPop) openPop._key = key; return; }
      if (openPop && !e.target.closest('.menu')) closePop();

      // nav toggle (mobile)
      if (e.target.closest('[data-nav-toggle]')) {
        document.querySelector('.app').classList.toggle('nav-open'); }
      // collapse (desktop)
      if (e.target.closest('[data-collapse]')) {
        document.querySelector('.app').classList.toggle('collapsed');
        const ic = e.target.closest('[data-collapse]').querySelector('svg');
      }
      // modal open
      const mo = e.target.closest('[data-modal]');
      if (mo) { e.preventDefault(); modalFromTemplate(mo.dataset.modal); }
      // toast demo
      const tt = e.target.closest('[data-toast]');
      if (tt) { const [ty, ...rest] = tt.dataset.toast.split('|'); toast(ty, rest[0], rest[1]); }
      // lightbox
      const lb = e.target.closest('[data-lightbox]');
      if (lb) { const img = lb.querySelector('img') || lb; lightbox(lb.dataset.lightbox || img.src); }
      // chip remove
      const cx = e.target.closest('.chip .x');
      if (cx) cx.closest('.chip').remove();
    });

    // keyboard: "/" focuses search
    document.addEventListener('keydown', e => {
      if (e.key === '/' && !/INPUT|TEXTAREA/.test(document.activeElement.tagName)) {
        const s = document.getElementById('globalSearch'); if (s) { e.preventDefault(); s.focus(); } }
      if (e.key === 'Escape') { closePop(); document.querySelectorAll('.overlay,.lightbox').forEach(o => o.remove()); }
    });

    // range live value
    document.querySelectorAll('input.range[data-out]').forEach(r => {
      const out = document.querySelector(r.dataset.out);
      const upd = () => { if (out) out.textContent = r.value; };
      r.addEventListener('input', upd); upd();
    });

    // char counter
    document.querySelectorAll('textarea[data-count]').forEach(t => {
      const out = document.querySelector(t.dataset.count);
      const upd = () => { if (out) out.textContent = t.value.length; };
      t.addEventListener('input', upd); upd();
    });

    window.dispatchEvent(new Event('shell:ready'));
  }

  window.CrewUI = { toast, openModal, lightbox, initTabs };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mount);
  else mount();
})();
