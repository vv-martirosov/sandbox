/* =====================================================================
   AI UCP · Widget Kit runtime (изолированный)
   - инъекция SVG-спрайта иконок
   - поведения компонентов (карусели, тоглы, степперы, скролл, билет, карта)
   - каталог KWIDGETS — источник виджетов для конструкторов экрана
   Экспортирует window.KWidgets: { list, byKey, cats, render(key), enhance(root) }
   ===================================================================== */
(function () {
  'use strict';

  /* ---------- SVG-спрайт ---------- */
  var SPRITE = '<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>' +
    '<symbol id="i-close" viewBox="0 0 24 24"><path d="M5 5L19 19M19 5L5 19"/></symbol>' +
    '<symbol id="i-share" viewBox="0 0 24 24"><path d="M13 4L21 11L13 18V14C8 14 5 16 3 20C3 14 6 9 13 8V4Z"/></symbol>' +
    '<symbol id="i-chevron" viewBox="0 0 24 24"><path d="M9 5L16 12L9 19"/></symbol>' +
    '<symbol id="i-chevron-left" viewBox="0 0 24 24"><path d="M15 5L8 12L15 19"/></symbol>' +
    '<symbol id="i-back" viewBox="0 0 24 24"><path d="M20 12H4M10 6L4 12L10 18"/></symbol>' +
    '<symbol id="i-add" viewBox="0 0 24 24"><path d="M12 5V19M5 12H19"/></symbol>' +
    '<symbol id="i-minus" viewBox="0 0 24 24"><path d="M5 12H19"/></symbol>' +
    '<symbol id="i-check" viewBox="0 0 24 24"><path d="M6 12.5L10 16.5L18 8"/></symbol>' +
    '<symbol id="i-walk" viewBox="0 0 24 24"><circle cx="13.5" cy="4" r="2" fill="currentColor" stroke="none"/><path d="M11 21L13 15L16 18V22M9 12L12 8.5L15 11.5L18 12.5M12 8.5L11 15L8 17"/></symbol>' +
    '<symbol id="i-map" viewBox="0 0 24 24"><path d="M3 6L9 3L15 6L21 3V18L15 21L9 18L3 21V6ZM9 3V18M15 6V21"/></symbol>' +
    '<symbol id="i-star" viewBox="0 0 24 24"><path d="M12 2.5L14.9 8.6L21.5 9.4L16.6 13.9L17.9 20.5L12 17.2L6.1 20.5L7.4 13.9L2.5 9.4L9.1 8.6Z" fill="currentColor" stroke="none"/></symbol>' +
    '<symbol id="i-clock" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7V12L15 14"/></symbol>' +
    '<symbol id="i-users" viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20C3 16.5 5.5 14.5 9 14.5S15 16.5 15.5 20ZM15 4.8A3.5 3.5 0 0 1 15 11.2M17.5 14.8C19.8 15.5 21.2 17.3 21.5 20"/></symbol>' +
    '<symbol id="i-user" viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4 21C4.5 16.5 8 14.5 12 14.5S19.5 16.5 20 21"/></symbol>' +
    '<symbol id="i-plane" viewBox="0 0 24 24"><path d="M21 12L3 5L6 12L3 19Z" fill="currentColor" stroke="none"/></symbol>' +
    '<symbol id="i-sparkle" viewBox="0 0 24 24"><path d="M14 6L15.8 12.2L22 14L15.8 15.8L14 22L12.2 15.8L6 14L12.2 12.2ZM6 2L6.8 4.2L9 5L6.8 5.8L6 8L5.2 5.8L3 5L5.2 4.2Z" fill="currentColor" stroke="none"/></symbol>' +
    '<symbol id="i-play" viewBox="0 0 24 24"><path d="M8 5V19L19 12Z" fill="currentColor" stroke="none"/></symbol>' +
    '<symbol id="i-calendar" viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="16" rx="3"/><path d="M3 10H21M8 3V7M16 3V7"/></symbol>' +
    '<symbol id="i-search" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M20 20L16 16"/></symbol>' +
    '<symbol id="i-locate" viewBox="0 0 24 24"><circle cx="12" cy="12" r="7"/><circle cx="12" cy="12" r="2.5" fill="currentColor" stroke="none"/><path d="M12 2V5M12 19V22M2 12H5M19 12H22"/></symbol>' +
    '<symbol id="i-shield" viewBox="0 0 24 24"><path d="M12 3L20 6V11C20 16 16.5 19.5 12 21C7.5 19.5 4 16 4 11V6ZM8.5 12L11 14.5L15.5 9.5"/></symbol>' +
    '<symbol id="i-bag" viewBox="0 0 24 24"><path d="M5 8H19L18 21H6ZM9 8V6A3 3 0 0 1 15 6V8"/></symbol>' +
    '<symbol id="i-heart" viewBox="0 0 24 24"><path d="M12 20C12 20 4 15 4 9.5A4 4 0 0 1 12 7A4 4 0 0 1 20 9.5C20 15 12 20 12 20Z"/></symbol>' +
    '<symbol id="i-ticket" viewBox="0 0 24 24"><path d="M3 6H21V10A2 2 0 0 0 21 14V18H3V14A2 2 0 0 0 3 10ZM15 6V18"/></symbol>' +
    '<symbol id="i-paw" viewBox="0 0 24 24"><g fill="currentColor" stroke="none"><circle cx="5.5" cy="10" r="2.2"/><circle cx="9.2" cy="5.8" r="2.2"/><circle cx="14.8" cy="5.8" r="2.2"/><circle cx="18.5" cy="10" r="2.2"/><path d="M12 11.5C9 11.5 6 15 6 17.8C6 19.6 7.6 20.5 9.2 20C10.2 19.7 11 19.3 12 19.3S13.8 19.7 14.8 20C16.4 20.5 18 19.6 18 17.8C18 15 15 11.5 12 11.5Z"/></g></symbol>' +
    '<symbol id="i-book" viewBox="0 0 24 24"><path d="M4 19V5A2 2 0 0 1 6 3H20V17H6A2 2 0 0 0 4 19ZM4 19A2 2 0 0 0 6 21H20V17"/></symbol>' +
    '<symbol id="i-syringe" viewBox="0 0 24 24"><path d="M17 3L21 7M19 5L9.5 14.5M15 5L19 9M9 9L15 15M11.5 12.5L4 20"/></symbol>' +
    '<symbol id="i-flask" viewBox="0 0 24 24"><path d="M9 3H15M10 3V9L4.6 18.6A1.6 1.6 0 0 0 6 21H18A1.6 1.6 0 0 0 19.4 18.6L14 9V3M7 15H17"/></symbol>' +
    '<symbol id="i-visit" viewBox="0 0 24 24"><path d="M5 3V9A5 5 0 0 0 15 9V3M10 14V16A4 4 0 0 0 18 16V13"/><circle cx="18" cy="11" r="2"/></symbol>' +
    '<symbol id="i-note" viewBox="0 0 24 24"><path d="M5 3H15L19 7V21H5ZM14 3V8H19M8 12H16M8 16H13"/></symbol>' +
    '<symbol id="i-fork" viewBox="0 0 24 24"><path d="M7 3V21M4 3V8A3 3 0 0 0 10 8V3M17 21V3C15 5 14 8 14 11V14H17"/></symbol>' +
    '<symbol id="i-chat" viewBox="0 0 24 24"><path d="M4 12A8 8 0 1 1 7.5 18.6L4 20L5 16.5A8 8 0 0 1 4 12Z"/><g fill="currentColor" stroke="none"><circle cx="8.5" cy="12" r="1.2"/><circle cx="12" cy="12" r="1.2"/><circle cx="15.5" cy="12" r="1.2"/></g></symbol>' +
    '<symbol id="i-mic" viewBox="0 0 24 24"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5.5 11A6.5 6.5 0 0 0 18.5 11M12 17.5V21"/></symbol>' +
    '<symbol id="i-info" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 11V16.5"/><circle cx="12" cy="7.8" r="1.1" fill="currentColor" stroke="none"/></symbol>' +
    '<symbol id="i-pill" viewBox="0 0 24 24"><path d="M10.5 20.5L20.5 10.5A4.95 4.95 0 0 0 13.5 3.5L3.5 13.5A4.95 4.95 0 0 0 10.5 20.5ZM8.5 8.5L15.5 15.5"/></symbol>' +
    '<symbol id="i-bell" viewBox="0 0 24 24"><path d="M6 16V11A6 6 0 0 1 18 11V16L19.5 18H4.5ZM10 20.5A2.2 2.2 0 0 0 14 20.5"/></symbol>' +
    '<symbol id="i-target" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.6" fill="currentColor" stroke="none"/></symbol>' +
    '<symbol id="i-card" viewBox="0 0 24 24"><rect x="3" y="6" width="18" height="13" rx="3"/><path d="M3 10.5H21M7 15H10"/></symbol>' +
    '<symbol id="i-back10" viewBox="0 0 24 24"><path d="M5 12A7 7 0 1 0 7.1 7M7 3.5V7.2H3.3"/></symbol>' +
    '<symbol id="i-fwd10" viewBox="0 0 24 24"><path d="M19 12A7 7 0 1 1 16.9 7M17 3.5V7.2H20.7"/></symbol>' +
    '<symbol id="i-bolt" viewBox="0 0 24 24"><path d="M13 2L4 14H11L10 22L20 9H13Z" fill="currentColor" stroke="none"/></symbol>' +
    '<symbol id="i-folder" viewBox="0 0 24 24"><path d="M3 7A2 2 0 0 1 5 5H9L11 7H19A2 2 0 0 1 21 9V17A2 2 0 0 1 19 19H5A2 2 0 0 1 3 17Z"/></symbol>' +
    '<symbol id="i-bulb" viewBox="0 0 24 24"><path d="M9 18H15M10 21H14M12 3A6 6 0 0 0 8 13.5C9 14.5 9 15.5 9 16H15C15 15.5 15 14.5 16 13.5A6 6 0 0 0 12 3Z"/></symbol>' +
    '<symbol id="i-briefcase" viewBox="0 0 24 24"><path d="M3 8H21V19H3ZM8 8V5H16V8M3 13H21"/></symbol>' +
    '<symbol id="i-edit" viewBox="0 0 24 24"><path d="M4 20H8L19 9L15 5L4 16ZM13 7L17 11"/></symbol>' +
    '<symbol id="i-heartbeat" viewBox="0 0 24 24"><path d="M3 12H7L9.5 6L13.5 18L16 12H21"/></symbol>' +
    '<symbol id="i-moon" viewBox="0 0 24 24"><path d="M20 14.5A8 8 0 1 1 9.5 4A6.5 6.5 0 0 0 20 14.5Z"/></symbol>' +
    '<symbol id="i-warn" viewBox="0 0 24 24"><path d="M12 4L21 20H3ZM12 10V14"/><circle cx="12" cy="17" r="1" fill="currentColor" stroke="none"/></symbol>' +
    '<symbol id="i-eye" viewBox="0 0 24 24"><path d="M2 12C4.5 7 8 5 12 5S19.5 7 22 12C19.5 17 16 19 12 19S4.5 17 2 12Z"/><circle cx="12" cy="12" r="3"/></symbol>' +
    '<symbol id="i-phone" viewBox="0 0 24 24"><path d="M5 4H9L11 9L8.5 10.5A11 11 0 0 0 13.5 15.5L15 13L20 15V19A2 2 0 0 1 18 21A16 16 0 0 1 3 6A2 2 0 0 1 5 4Z"/></symbol>' +
    '<symbol id="i-external" viewBox="0 0 24 24"><path d="M14 4H20V10M20 4L11 13M18 14V19H5V6H10"/></symbol>' +
    '<symbol id="i-pin" viewBox="0 0 24 24"><path d="M12 22C12 22 19 15 19 9.5A7 7 0 0 0 5 9.5C5 15 12 22 12 22Z"/><circle cx="12" cy="9.5" r="2.5"/></symbol>' +
    '<symbol id="i-coin" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M9 9.5H13A2 2 0 0 1 13 13.5H9V8M9 13.5V16M8 15H12"/></symbol>' +
    '<symbol id="i-scissors" viewBox="0 0 24 24"><circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M8.5 7.5L20 18M8.5 16.5L20 6"/></symbol>' +
    '<symbol id="i-clinic" viewBox="0 0 24 24"><path d="M9 3H15V9H21V15H15V21H9V15H3V9H9Z"/></symbol>' +
    '<symbol id="wx-sun" viewBox="0 0 24 24"><circle cx="12" cy="12" r="4.5" fill="#F7B731"/><path d="M12 2V4.5M12 19.5V22M2 12H4.5M19.5 12H22M4.9 4.9L6.6 6.6M17.4 17.4L19.1 19.1M4.9 19.1L6.6 17.4M17.4 6.6L19.1 4.9" stroke="#F7B731" stroke-width="1.8" stroke-linecap="round" fill="none"/></symbol>' +
    '<symbol id="wx-cloud" viewBox="0 0 24 24"><path d="M7 18H17.5A3.5 3.5 0 0 0 17.5 11A5 5 0 0 0 8 10A4 4 0 0 0 7 18Z" fill="#A9C8EE"/></symbol>' +
    '<symbol id="wx-rain" viewBox="0 0 24 24"><path d="M7 15H17.5A3.5 3.5 0 0 0 17.5 8A5 5 0 0 0 8 7A4 4 0 0 0 7 15Z" fill="#8DB6EA"/><path d="M9 18L8 20.5M13 18L12 20.5M17 18L16 20.5" stroke="#3D8BEF" stroke-width="1.6" stroke-linecap="round" fill="none"/></symbol>' +
    '<symbol id="wx-snow" viewBox="0 0 24 24"><path d="M7 15H17.5A3.5 3.5 0 0 0 17.5 8A5 5 0 0 0 8 7A4 4 0 0 0 7 15Z" fill="#8DB6EA"/><g fill="#4FB8E8"><circle cx="8.5" cy="19" r="1.1"/><circle cx="12.5" cy="20.5" r="1.1"/><circle cx="16.5" cy="19" r="1.1"/></g></symbol>' +
    '<symbol id="wx-partly" viewBox="0 0 24 24"><circle cx="15" cy="8" r="3.5" fill="#F7B731"/><path d="M6 19H15.5A3.5 3.5 0 0 0 15.5 12A5 5 0 0 0 6.5 11.5A3.8 3.8 0 0 0 6 19Z" fill="#A9C8EE"/></symbol>' +
    '</defs></svg>';

  function injectSprite() {
    if (document.getElementById('kw-sprite')) return;
    var d = document.createElement('div');
    d.id = 'kw-sprite'; d.style.cssText = 'position:absolute;width:0;height:0;overflow:hidden';
    d.innerHTML = SPRITE;
    document.body.insertBefore(d, document.body.firstChild);
  }

  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return [].slice.call((r || document).querySelectorAll(s)); };

  /* ---------- Глобальные делегированные поведения ---------- */
  var wired = false;
  function wireGlobal() {
    if (wired) return; wired = true;
    document.addEventListener('click', function (e) {
      var item = e.target.closest('[data-k-item]');
      if (item) {
        var group = item.closest('[data-k-group]');
        if (group) {
          var cls = item.classList.contains('k-day') ? 'is-selected' : 'is-active';
          $$('[data-k-item]', group).filter(function (n) { return n.closest('[data-k-group]') === group; })
            .forEach(function (n) { n.classList.remove(cls); n.removeAttribute('aria-selected'); });
          item.classList.add(cls); item.setAttribute('aria-selected', 'true');
          group.dispatchEvent(new CustomEvent('k-select', { detail: item }));
        }
      }
      var tg = e.target.closest('[data-k-toggle]');
      if (tg) { var on = tg.classList.toggle('is-on'); tg.setAttribute('aria-checked', String(on)); }
      var ck = e.target.closest('[data-k-check]');
      if (ck) { e.preventDefault(); ck.classList.toggle('is-done'); }
      var st = e.target.closest('[data-k-step]');
      if (st) { var out = $('output', st.closest('[data-k-stepper]')); if (out) { out.value = out.textContent = Math.max(0, Number(out.textContent) + Number(st.dataset.kStep)); } }
    });
  }

  /* ---------- enhance(root): карусели, vscroll, месяц, билет, карта ---------- */
  function enhance(root) {
    root = root || document;
    // месяц
    $$('[data-k-month]', root).forEach(function (el) {
      if (el._kInit) return; el._kInit = 1;
      var p = el.dataset.kMonth.split('-').map(Number), y = p[0], m = p[1];
      var dots = { 2: ['ok', 'star'], 9: ['ok'], 17: ['ok', 'star', 'blue'] };
      var first = (new Date(y, m - 1, 1).getDay() + 6) % 7, days = new Date(y, m, 0).getDate();
      var html = ['пн', 'вт', 'ср', 'чт', 'пт', 'сб', 'вс'].map(function (d) { return '<span class="k-month__wd">' + d + '</span>'; }).join('');
      html += new Array(first + 1).join('<span></span>');
      for (var d = 1; d <= days; d++) {
        var dd = (dots[d] || []).map(function (c) { return '<i class="k-dot" style="--c:var(--k-' + c + ')"></i>'; }).join('');
        html += '<button class="k-day' + (d === 4 ? ' is-selected' : '') + '" type="button" data-k-item><b>' + d + '</b><span class="k-day__dots">' + dd + '</span></button>';
      }
      el.innerHTML = html;
    });
    // карусели
    $$('[data-k-carousel]', root).forEach(function (track) {
      if (track._kInit) return; track._kInit = 1;
      var rootEl = track.closest('.k-carousel') || track.parentElement;
      var items = [].slice.call(track.children);
      var prev = $('[data-k-prev]', rootEl), next = $('[data-k-next]', rootEl);
      var dots = $('[data-k-dots]', rootEl), counter = $('[data-k-counter]', rootEl);
      if (dots) dots.innerHTML = items.map(function () { return '<i></i>'; }).join('');
      var base = function () { return items[0] ? items[0].offsetLeft : 0; };
      var go = function (i) { track.scrollTo({ left: items[i].offsetLeft - base() }); };
      var step = function () { return Math.max(track.clientWidth * 0.8, items[0] ? items[0].offsetWidth : 100); };
      if (prev) prev.addEventListener('click', function () { track.scrollBy({ left: -step() }); });
      if (next) next.addEventListener('click', function () { track.scrollBy({ left: step() }); });
      var current = -1;
      var update = function () {
        var max = track.scrollWidth - track.clientWidth;
        if (prev) prev.disabled = track.scrollLeft <= 2;
        if (next) next.disabled = track.scrollLeft >= max - 2;
        var idx = 0, best = Infinity;
        items.forEach(function (it, i) { var dd = Math.abs(it.offsetLeft - base() - track.scrollLeft); if (dd < best) { best = dd; idx = i; } });
        if (track.scrollLeft >= max - 2 && max > 0) idx = items.length - 1;
        if (dots) $$('i', dots).forEach(function (d, i) { d.classList.toggle('is-active', i === idx); });
        if (counter) counter.textContent = (idx + 1) + ' из ' + items.length;
        if (idx !== current) { current = idx; track.dispatchEvent(new CustomEvent('k-slide', { detail: idx })); }
      };
      track.addEventListener('scroll', function () { requestAnimationFrame(update); }, { passive: true });
      if (dots) dots.addEventListener('click', function (e) { var i = $$('i', dots).indexOf(e.target); if (i >= 0) go(i); });
      track._kGo = go;
      var startX = 0, startLeft = 0, moved = false, down = false;
      track.addEventListener('pointerdown', function (e) { if (e.pointerType !== 'mouse') return; down = true; moved = false; startX = e.clientX; startLeft = track.scrollLeft; });
      window.addEventListener('pointermove', function (e) { if (!down) return; var dx = e.clientX - startX; if (Math.abs(dx) > 4) { moved = true; track.classList.add('is-dragging'); } track.scrollLeft = startLeft - dx; });
      window.addEventListener('pointerup', function () { if (!down) return; down = false; track.classList.remove('is-dragging'); if (moved) go(current < 0 ? 0 : current); });
      track.addEventListener('click', function (e) { if (moved) { e.stopPropagation(); e.preventDefault(); moved = false; } }, true);
      update();
    });
    // vscroll
    $$('[data-k-vscroll]', root).forEach(function (wrap) {
      if (wrap._kInit) return; wrap._kInit = 1;
      var box = wrap.firstElementChild;
      var upd = function () { wrap.classList.toggle('has-top', box.scrollTop > 4); wrap.classList.toggle('has-bottom', box.scrollTop + box.clientHeight < box.scrollHeight - 4); };
      box.addEventListener('scroll', upd, { passive: true }); upd();
    });
    // карта
    $$('[data-k-map]', root).forEach(function (map) {
      if (map._kInit) return; map._kInit = 1;
      var track = $('[data-k-map-track]', map);
      var setActive = function (i) { $$('[data-k-pin]', map).forEach(function (n) { n.classList.toggle('is-active', Number(n.dataset.kPin) === i); }); };
      if (track) track.addEventListener('k-slide', function (e) { setActive(e.detail); });
      $$('.k-map__pin', map).forEach(function (pin) { pin.addEventListener('click', function () { var i = Number(pin.dataset.kPin); setActive(i); if (track && track._kGo) track._kGo(i); }); });
    });
    // билет туда/обратно
    var TICKET = {
      there: { status: ['В пути', ''], flight: 'SU100 · 7 фев', t1: '08:20', t2: '14:20', c1: ['Екатеринбург', 'SVX'], c2: ['Москва', 'VKO'], term: 'B', desk: '8–9 стойки', gate: '5' },
      back: { status: ['Регистрация до 16:40', 'k-pill--yellow'], flight: 'SU101 · 9 фев', t1: '18:10', t2: '20:10', c1: ['Москва', 'VKO'], c2: ['Екатеринбург', 'SVX'], term: 'A', desk: '12–14 стойки', gate: '14' }
    };
    $$('[data-k-ticket]', root).forEach(function (t) {
      if (t._kInit) return; t._kInit = 1;
      var sw = $('[data-k-ticket-switch]', t); if (!sw) return;
      sw.addEventListener('k-select', function (e) {
        var d = TICKET[e.detail.dataset.dir], set = function (k, v) { var el = $('[data-k-ticket-' + k + ']', t); if (el) el.textContent = v; };
        var stx = $('[data-k-ticket-status]', t); stx.textContent = d.status[0]; stx.className = 'k-pill k-pill--s ' + d.status[1];
        set('flight', d.flight); set('t1', d.t1); set('t2', d.t2); set('term', d.term); set('desk', d.desk); set('gate', d.gate);
        $('[data-k-ticket-c1]', t).innerHTML = d.c1[0] + '<span>' + d.c1[1] + '</span>';
        $('[data-k-ticket-c2]', t).innerHTML = d.c2[0] + '<span>' + d.c2[1] + '</span>';
      });
    });
  }

  /* ===================================================================
     КАТАЛОГ ВИДЖЕТОВ — источник для реестра и конструкторов экрана
     =================================================================== */
  var CATS = {
    nav: 'Навигация', content: 'Контент и медиа', list: 'Строки и списки',
    data: 'Данные и графики', ai: 'ИИ-агент', compound: 'Составные', control: 'Контролы'
  };

  var W = [
    { key: 'navbar', name: 'Шапка экрана', cat: 'nav', cls: '.k-navbar',
      html: '<div class="k-navbar"><div class="k-navbar__side"><svg class="k-i"><use href="#i-back"/></svg></div><div class="k-navbar__title">Заголовок</div><div class="k-navbar__side k-navbar__side--end"><svg class="k-i"><use href="#i-share"/></svg></div></div>' },
    { key: 'title', name: 'Заголовок экрана', cat: 'nav', cls: '.k-title--screen',
      html: '<div class="k-title k-title--screen"><h2>Результат готов</h2><p>Собрал персональную подборку под ваш запрос</p></div>' },
    { key: 'segmented', name: 'Сегмент-переключатель', cat: 'control', cls: '.k-segmented',
      html: '<div class="k-segmented" data-k-group><button class="k-segmented__item is-active" type="button" data-k-item>Обзор</button><button class="k-segmented__item" type="button" data-k-item>Детали</button><button class="k-segmented__item" type="button" data-k-item>История</button></div>' },
    { key: 'chips', name: 'Чипсы-фильтр', cat: 'control', cls: '.k-chip',
      html: '<div class="k-carousel"><div class="k-carousel__track" data-k-carousel data-k-group style="--gap:8px"><button class="k-chip is-active" type="button" data-k-item>Все</button><button class="k-chip" type="button" data-k-item>Новые</button><button class="k-chip" type="button" data-k-item>Избранное</button><button class="k-chip" type="button" data-k-item>Архив</button></div></div>' },
    { key: 'tabbar', name: 'Нижний таб-бар', cat: 'nav', cls: '.k-tabbar',
      html: '<nav class="k-tabbar" data-k-group><button class="k-tabbar__item is-active" type="button" data-k-item><svg class="k-i"><use href="#i-target"/></svg>Обзор</button><button class="k-tabbar__item" type="button" data-k-item><svg class="k-i"><use href="#i-calendar"/></svg>План</button><button class="k-tabbar__item" type="button" data-k-item><svg class="k-i"><use href="#i-chat"/></svg>Агент</button><button class="k-tabbar__item" type="button" data-k-item><svg class="k-i"><use href="#i-user"/></svg>Профиль</button></nav>' },
    { key: 'cta', name: 'Кнопка CTA', cat: 'control', cls: '.k-btn',
      html: '<button class="k-btn k-btn--block" type="button">Продолжить</button>' },
    { key: 'media', name: 'Медиа-карточка', cat: 'content', cls: '.k-media',
      html: '<div class="k-media k-media--c1 k-media--overlay" style="--h:190px"><div class="k-media__tags"><span class="k-pill k-pill--white k-pill--s">Сегодня · 20:00</span></div><span class="k-t-body-l" style="font-weight:600">Вечер джаза в центре</span><span class="k-t-small">Музыка, ужин и атмосфера</span></div>' },
    { key: 'content-card', name: 'Карточка контента', cat: 'content', cls: '.k-card--full',
      html: '<div class="k-card k-card--full"><div class="k-media k-media--c2 k-media--top" style="--h:140px"><div class="k-media__tags"><span class="k-pill k-pill--white k-pill--s">Подборка</span><span class="k-pill k-pill--s"><svg class="k-i k-i--xs"><use href="#i-sparkle"/></svg>94%</span></div></div><div class="k-spread"><span class="k-card__title">Аналитик данных</span><span class="k-rating k-rating--s"><svg class="k-i k-i--xs"><use href="#i-star"/></svg>4,8</span></div><span class="k-card__meta">9 месяцев · онлайн · диплом</span><button class="k-btn k-btn--s k-btn--block" type="button">Подробнее</button></div>' },
    { key: 'carousel', name: 'Карусель карточек', cat: 'content', cls: '.k-carousel',
      html: '<div class="k-carousel"><div class="k-section-head"><h3>Рекомендации</h3><a href="#">Все</a></div><div class="k-carousel__track" data-k-carousel><div class="k-card k-card--m"><div class="k-media" style="--h:120px"><span class="k-pill k-pill--white k-pill--s">Топ</span></div><span class="k-card__title">Вариант 1</span><span class="k-card__meta k-t-small">описание</span></div><div class="k-card k-card--m"><div class="k-media k-media--c3" style="--h:120px"></div><span class="k-card__title">Вариант 2</span><span class="k-card__meta k-t-small">описание</span></div><div class="k-card k-card--m"><div class="k-media k-media--c4" style="--h:120px"></div><span class="k-card__title">Вариант 3</span><span class="k-card__meta k-t-small">описание</span></div></div></div>' },
    { key: 'product', name: 'Карточка товара', cat: 'content', cls: '.k-card--m',
      html: '<div class="k-carousel"><div class="k-carousel__track" data-k-carousel style="align-items:flex-start"><div class="k-card k-card--m" style="--w:150px"><div class="k-media k-media--thumb k-media--top" style="--h:150px"><span class="k-pill k-pill--yellow k-pill--s">−15%</span></div><div class="k-card__price">149 ₽ <span class="k-t-small k-strike">179 ₽</span></div><span class="k-card__meta" style="color:var(--k-text)">Товар на ветке</span><button class="k-btn k-btn--s k-btn--mint k-btn--block" type="button"><svg class="k-i k-i--s"><use href="#i-add"/></svg>В корзину</button></div><div class="k-card k-card--m" style="--w:150px"><div class="k-media k-media--thumb k-media--top" style="--h:150px"></div><div class="k-card__price">99 ₽</div><span class="k-card__meta" style="color:var(--k-text)">Ещё товар</span><div class="k-stepper k-stepper--dark k-stepper--block" data-k-stepper><button type="button" data-k-step="-1"><svg class="k-i"><use href="#i-minus"/></svg></button><output>1</output><button type="button" data-k-step="1"><svg class="k-i"><use href="#i-add"/></svg></button></div></div></div></div>' },
    { key: 'row-list', name: 'Список строк', cat: 'list', cls: '.k-list',
      html: '<div class="k-list"><div class="k-row"><span class="k-badge-icon k-badge-icon--mint"><svg class="k-i"><use href="#i-check"/></svg></span><div class="k-row__body"><span class="k-row__title">Первый пункт</span><span class="k-row__sub">короткое описание</span></div><svg class="k-i k-i--s k-row__chev"><use href="#i-chevron"/></svg></div><div class="k-row"><span class="k-badge-icon k-badge-icon--blue"><svg class="k-i"><use href="#i-info"/></svg></span><div class="k-row__body"><span class="k-row__title">Второй пункт</span><span class="k-row__sub">короткое описание</span></div><span class="k-pill k-pill--yellow k-pill--s">new</span></div><div class="k-row"><span class="k-badge-icon k-badge-icon--orange"><svg class="k-i"><use href="#i-bell"/></svg></span><div class="k-row__body"><span class="k-row__title">Третий пункт</span></div><button class="k-toggle is-on" type="button" role="switch" aria-checked="true" data-k-toggle></button></div></div>' },
    { key: 'tiles', name: 'Плитки-показатели', cat: 'list', cls: '.k-tiles',
      html: '<div class="k-tiles k-tiles--3"><div class="k-tile"><span class="k-tile__value--big">6</span><span class="k-tile__label">визитов</span></div><div class="k-tile"><span class="k-tile__value--big">4</span><span class="k-tile__label">готово</span></div><div class="k-tile k-tile--mint"><span class="k-tile__value--big">2</span><span class="k-tile__label">впереди</span></div></div>' },
    { key: 'event', name: 'Событие календаря', cat: 'list', cls: '.k-event',
      html: '<div class="k-event"><div class="k-event__time">10:30<small>11:00</small></div><i class="k-event__bar" style="--c:var(--k-ok)"></i><div class="k-stack" style="--gap:4px"><span class="k-row__title">Встреча с наставником</span><span class="k-row__sub">Онлайн · Zoom</span><span class="k-pill k-pill--white k-pill--s">Напомню за 30 мин</span></div></div>' },
    { key: 'banner', name: 'Баннер промо', cat: 'content', cls: '.k-banner',
      html: '<div class="k-banner"><i class="k-flag"></i><span class="k-banner__text"><b>0 ₽</b> по подписке</span><span class="k-banner__action">Подключить</span></div>' },
    { key: 'panel-goal', name: 'Панель-цель', cat: 'data', cls: '.k-panel--mint',
      html: '<div class="k-panel k-panel--mint k-panel--row"><div class="k-ring" style="--v:78;--s:84px;--ring-bg:var(--k-ring-panel)">78%</div><div class="k-stack" style="--gap:3px"><span class="k-row__title k-row__title--strong">Прогресс цели</span><span class="k-t-caption k-ok-text">Хорошо · +4 за месяц</span><span class="k-row__sub">Выполнено 6 из 9</span></div></div>' },
    { key: 'meter', name: 'Шкала прогресса', cat: 'data', cls: '.k-meter',
      html: '<div class="k-panel"><div class="k-meter"><div class="k-meter__head"><span>Готовность</span><span class="k-t-caption k-muted">65%</span></div><div class="k-meter__track"><i class="k-meter__fill" style="--v:65%"></i></div></div></div>' },
    { key: 'bars', name: 'Столбцы', cat: 'data', cls: '.k-bars',
      html: '<div class="k-panel"><div class="k-spread"><span class="k-row__title k-row__title--strong">Эта неделя</span><span class="k-t-caption k-muted">4,5 ч</span></div><div class="k-bars" style="--h:96px"><div class="k-bars__col"><i class="k-bars__bar k-bars__bar--mint" style="--v:33%"></i>Пн</div><div class="k-bars__col"><i class="k-bars__bar k-bars__bar--mint" style="--v:50%"></i>Вт</div><div class="k-bars__col"><i class="k-bars__bar k-bars__bar--mint" style="--v:20%"></i>Ср</div><div class="k-bars__col is-now"><i class="k-bars__bar k-bars__bar--now" style="--v:66%"></i>Чт</div><div class="k-bars__col"><i class="k-bars__bar" style="--v:0"></i>Пт</div></div></div>' },
    { key: 'ring', name: 'Кольцо прогресса', cat: 'data', cls: '.k-ring',
      html: '<div class="k-hstack" style="--gap:16px;justify-content:center"><div class="k-ring" style="--v:25">25%</div><div class="k-ring" style="--v:56">56%</div><div class="k-ring" style="--v:100">100%</div></div>' },
    { key: 'weather', name: 'Погода по часам', cat: 'data', cls: '.k-weather-hours',
      html: '<div class="k-panel"><div class="k-weather-hours"><div>Сейчас<svg class="k-wx"><use href="#wx-sun"/></svg><b>6°</b></div><div>14<svg class="k-wx"><use href="#wx-partly"/></svg><b>4°</b></div><div>15<svg class="k-wx"><use href="#wx-cloud"/></svg><b>4°</b></div><div>16<svg class="k-wx"><use href="#wx-rain"/></svg><b>3°</b></div><div>17<svg class="k-wx"><use href="#wx-snow"/></svg><b>2°</b></div></div></div>' },
    { key: 'datestrip', name: 'Лента дат', cat: 'data', cls: '.k-datestrip',
      html: '<div class="k-carousel"><div class="k-carousel__track" data-k-carousel data-k-group style="--gap:4px"><button class="k-day" type="button" data-k-item><span class="k-day__wd">пн</span><b>28</b><span class="k-day__dots"></span></button><button class="k-day is-today" type="button" data-k-item><span class="k-day__wd">вт</span><b>29</b><span class="k-day__dots"></span></button><button class="k-day" type="button" data-k-item><span class="k-day__wd">ср</span><b>30</b><span class="k-day__dots"></span></button><button class="k-day is-selected" type="button" data-k-item><span class="k-day__wd">чт</span><b>1</b><span class="k-day__dots"><i class="k-dot" style="--c:var(--k-ok)"></i></span></button><button class="k-day" type="button" data-k-item><span class="k-day__wd">пт</span><b>2</b><span class="k-day__dots"><i class="k-dot" style="--c:var(--k-star)"></i></span></button><button class="k-day" type="button" data-k-item><span class="k-day__wd">сб</span><b>3</b><span class="k-day__dots"></span></button><button class="k-day" type="button" data-k-item><span class="k-day__wd">вс</span><b>4</b><span class="k-day__dots"></span></button></div></div>' },
    { key: 'msg-ai', name: 'Реплика ассистента', cat: 'ai', cls: '.k-msg',
      html: '<div class="k-stack"><div class="k-msg"><span class="k-orb k-orb--s"><svg class="k-i k-i--s"><use href="#i-sparkle"/></svg></span><div class="k-msg__bubble">Привет! Помогу с задачей. Что нужно сейчас?</div></div><div class="k-msg k-msg--user"><div class="k-msg__bubble">Собери план на день</div></div></div>' },
    { key: 'ai-hint', name: 'ИИ-совет', cat: 'ai', cls: '.k-panel--ai',
      html: '<div class="k-panel k-panel--ai"><div class="k-panel__head"><svg class="k-i k-i--s"><use href="#i-sparkle"/></svg>Совет ассистента</div><p class="k-t-body" style="margin:0">Осталось 3 пункта. Записать вас на удобное время?</p><div class="k-hstack"><button class="k-btn k-btn--s" type="button">Записать</button><button class="k-btn k-btn--s k-btn--outline" type="button">Позже</button></div></div>' },
    { key: 'ask', name: 'Поле агента', cat: 'ai', cls: '.k-ask',
      html: '<label class="k-ask"><svg class="k-i"><use href="#i-sparkle"/></svg><input type="text" placeholder="Спросить агента"><button class="k-icon-btn k-icon-btn--black k-icon-btn--s" type="button" aria-label="Голосом"><svg class="k-i k-i--s"><use href="#i-mic"/></svg></button></label>' },
    { key: 'cart', name: 'Мини-корзина', cat: 'compound', cls: '.k-panel--row',
      html: '<div class="k-panel k-panel--row" style="padding:16px"><div class="k-stack" style="--gap:2px;flex:1"><span class="k-row__sub">4 товара · доставка 15 мин</span><span class="k-t-h2">466 ₽</span></div><button class="k-btn k-btn--s" type="button"><svg class="k-i k-i--s"><use href="#i-bag"/></svg>Оформить</button></div>' },
    { key: 'ticket', name: 'Билет', cat: 'compound', cls: '.k-ticket',
      html: '<div class="k-ticket" data-k-ticket style="box-shadow:inset 0 0 0 1px var(--k-divider)"><div class="k-hstack" style="--gap:12px"><span class="k-pill k-pill--s" data-k-ticket-status>В пути</span><span class="k-t-caption k-muted" data-k-ticket-flight>SU100 · 7 фев</span></div><div class="k-ticket__times"><span data-k-ticket-t1>08:20</span><span class="k-ticket__line"><svg class="k-i"><use href="#i-plane"/></svg></span><span data-k-ticket-t2>14:20</span></div><div class="k-ticket__cities"><div data-k-ticket-c1>Екатеринбург<span>SVX</span></div><div data-k-ticket-c2>Москва<span>VKO</span></div></div><div class="k-ticket__info"><div><small>Терминал</small><b data-k-ticket-term>B</b></div><div><small>Регистрация</small><b data-k-ticket-desk>8–9 стойки</b></div><span class="k-gate"><svg class="k-i k-i--xs"><use href="#i-chevron"/></svg><span data-k-ticket-gate>5</span></span></div><div class="k-segmented" data-k-group data-k-ticket-switch><button class="k-segmented__item is-active" type="button" data-k-item data-dir="there">Туда</button><button class="k-segmented__item" type="button" data-k-item data-dir="back">Обратно</button></div></div>' },
    { key: 'empty', name: 'Пустое состояние', cat: 'compound', cls: '.k-empty',
      html: '<div class="k-empty"><i><svg class="k-i"><use href="#i-calendar"/></svg></i><b>Здесь пока пусто</b><p>Соберите первый экран из виджетов</p><button class="k-btn k-btn--s" type="button">Собрать</button></div>' },

    /* ---- добавлено: недостающие компоненты из UI-кита ---- */
    { key: 'calendar', name: 'Календарь (месяц)', cat: 'data', cls: '.k-month',
      html: '<div class="k-panel"><div class="k-section-head" style="margin-bottom:10px"><h3>Октябрь</h3><span>2026</span></div><div class="k-month" data-k-month="2026-10"></div></div>' },
    { key: 'table', name: 'Таблица', cat: 'data', cls: '.k-table',
      html: '<table class="k-table"><thead><tr><th>Показатель</th><th>Было</th><th>Стало</th></tr></thead><tbody><tr><td>Конверсия</td><td>2,1%</td><td>3,4%</td></tr><tr><td>Средний чек</td><td>1 240 ₽</td><td>1 380 ₽</td></tr><tr><td>Отклик агента</td><td>18 мин</td><td>6 мин</td></tr></tbody></table>' },
    { key: 'schedule', name: 'Расписание со статусами', cat: 'list', cls: '.k-schedule',
      html: '<div class="k-panel"><div class="k-schedule"><div class="k-schedule__item is-done"><div class="k-schedule__rail"></div><div class="k-schedule__body"><div class="k-schedule__time">09:00<span class="k-pill k-pill--s k-pill--gray">Завершено</span></div><div class="k-schedule__title">Открытие смены</div><div class="k-schedule__place">Зал 1</div></div></div><div class="k-schedule__item is-now"><div class="k-schedule__rail"></div><div class="k-schedule__body"><div class="k-schedule__time">11:30<span class="k-pill k-pill--s k-pill--green">Идёт</span></div><div class="k-schedule__title">Встреча с наставником</div><div class="k-schedule__place">Онлайн · Zoom</div></div></div><div class="k-schedule__item is-delayed"><div class="k-schedule__rail"></div><div class="k-schedule__body"><div class="k-schedule__time">14:00<span class="k-pill k-pill--s k-pill--yellow">Задержка</span></div><div class="k-schedule__title">Демо продукта</div><div class="k-schedule__place">Переговорная B</div></div></div><div class="k-schedule__item is-cancelled"><div class="k-schedule__rail"></div><div class="k-schedule__body"><div class="k-schedule__time">16:00<span class="k-pill k-pill--s k-pill--danger">Отменено</span></div><div class="k-schedule__title">Ретро спринта</div><div class="k-schedule__place">Зал 3</div></div></div></div></div>' },
    { key: 'metrics', name: 'Плитки-показатели (KV)', cat: 'list', cls: '.k-tile',
      html: '<div class="k-tiles"><div class="k-tile"><span class="k-tile__label"><svg class="k-i k-i--s"><use href="#i-target"/></svg>Цель</span><span class="k-tile__value--big">78%</span><span class="k-tile__note">+4 за месяц</span></div><div class="k-tile"><span class="k-tile__label"><svg class="k-i k-i--s"><use href="#i-clock"/></svg>Отклик</span><span class="k-tile__value--big">6<small>мин</small></span><span class="k-tile__note">−12 мин</span></div><div class="k-tile k-tile--mint"><span class="k-tile__label">Сессии</span><span class="k-tile__value--big">1 240</span><span class="k-tile__note">за неделю</span></div><div class="k-tile"><span class="k-tile__label">CSAT</span><span class="k-tile__value--big">4,8<small>из 5</small></span><span class="k-tile__note">98 оценок</span></div></div>' },
    { key: 'text', name: 'Текстовый блок', cat: 'content', cls: '.k-t-body',
      html: '<div class="k-stack" style="--gap:12px"><h3 class="k-t-h3" style="margin:0">Как проходит подбор</h3><p class="k-t-body" style="margin:0">Агент анализирует запрос, сверяется с базой знаний и предлагает лучшие варианты под задачу.</p><ol class="k-bullets k-bullets--num"><li>Опишите цель в свободной форме</li><li>Агент задаёт уточняющие вопросы</li><li>Получаете готовую подборку</li></ol></div>' },
    { key: 'accordion', name: 'Аккордион', cat: 'content', cls: '.k-accordion',
      html: '<div class="k-stack" style="--gap:0"><details class="k-accordion" open><summary>Как это работает<svg class="k-i"><use href="#i-add"/></svg></summary><div class="k-accordion__body"><p class="k-t-body" style="margin:0">Агент собирает данные, предлагает шаги и подтверждает действия перед запуском.</p></div></details><details class="k-accordion"><summary>Сколько это стоит<svg class="k-i"><use href="#i-add"/></svg></summary><div class="k-accordion__body"><p class="k-t-body" style="margin:0">Тариф зависит от числа активных сценариев и каналов.</p></div></details><details class="k-accordion"><summary>Нужна ли интеграция<svg class="k-i"><use href="#i-add"/></svg></summary><div class="k-accordion__body"><p class="k-t-body" style="margin:0">Подключение через коннекторы, без разработки на стороне клиента.</p></div></details></div>' },
    { key: 'toast', name: 'Уведомление (тост)', cat: 'content', cls: '.k-toast',
      html: '<div class="k-stack"><div class="k-toast"><span class="k-badge-icon k-badge-icon--mint"><svg class="k-i"><use href="#i-check"/></svg></span>Сценарий сохранён</div><div class="k-toast"><span class="k-badge-icon k-badge-icon--blue"><svg class="k-i"><use href="#i-info"/></svg></span>Новое сообщение от агента</div><div class="k-toast"><span class="k-badge-icon k-badge-icon--orange"><svg class="k-i"><use href="#i-warn"/></svg></span>Проверьте настройки канала</div></div>' },
    { key: 'section-head', name: 'Заголовок раздела', cat: 'nav', cls: '.k-section-head',
      html: '<div class="k-section-head"><h3>Рекомендации</h3><a href="#">Все</a></div>' },
    { key: 'steps', name: 'Шаги-прогресс', cat: 'nav', cls: '.k-steps',
      html: '<div class="k-steps"><div class="k-steps__item is-done">Запрос</div><div class="k-steps__item is-done">Анализ</div><div class="k-steps__item is-active">Подбор</div><div class="k-steps__item">Итог</div></div>' },
    { key: 'step-list', name: 'Шаги сценария', cat: 'nav', cls: '.k-step',
      html: '<div class="k-stack" style="--gap:0"><div class="k-step"><div class="k-step__rail"><div class="k-step__box"><b>1</b></div></div><div><b>Сбор данных</b><span>Агент уточняет цель и контекст</span></div></div><div class="k-step"><div class="k-step__rail"><div class="k-step__box"><b>2</b></div></div><div><b>Обработка</b><span>Сверка с базой знаний</span></div></div><div class="k-step"><div class="k-step__rail"><div class="k-step__box"><b>3</b></div></div><div><b>Результат</b><span>Готовая подборка и следующий шаг</span></div></div></div>' }
  ];

  var BY = {}; W.forEach(function (w) { BY[w.key] = w; });

  window.KWidgets = {
    list: W, byKey: BY, cats: CATS,
    render: function (key) { return BY[key] ? BY[key].html : ''; },
    enhance: enhance,
    injectSprite: injectSprite
  };

  function boot() { injectSprite(); wireGlobal(); enhance(document); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
